pig -x local -P user.properties sed.pig
